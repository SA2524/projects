function validateForm() {
    // Clear previous errors
    document.querySelectorAll('.error').forEach(error => error.textContent = '');

    let isValid = true;

    // Name validation
    const name = document.getElementById('name').value;
    if (!name) {
        document.getElementById('nameError').textContent = 'Name is required';
        isValid = false;
    }

    // Father's Name validation
    const fatherName = document.getElementById('fatherName').value;
    if (!fatherName) {
        document.getElementById('fatherNameError').textContent = "Father's Name is required";
        isValid = false;
    }

    // Mother's Name validation
    const motherName = document.getElementById('motherName').value;
    if (!motherName) {
        document.getElementById('motherNameError').textContent = "Mother's Name is required";
        isValid = false;
    }

    // Phone Number validation
    const phoneNumber = document.getElementById('phoneNumber').value;
    const phonePattern = /^[0-9]{10}$/;
    if (!phoneNumber || !phonePattern.test(phoneNumber)) {
        document.getElementById('phoneError').textContent = 'Valid phone number is required';
        isValid = false;
    }

    // Email validation
    const email = document.getElementById('email').value;
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email || !emailPattern.test(email)) {
        document.getElementById('emailValidation').textContent = 'Valid email is required';
        isValid = false;
    } else {
        document.getElementById('emailValidation').textContent = 'Email is valid';
        document.getElementById('emailValidation').classList.remove('error');
        document.getElementById('emailValidation').classList.add('success');
    }

    // Date of Birth validation
    const dobDay = document.getElementById('dobDay').value;
    const dobMonth = document.getElementById('dobMonth').value;
    const dobYear = document.getElementById('dobYear').value;
    if (!dobDay || !dobMonth || !dobYear) {
        document.getElementById('dobError').textContent = 'Complete Date of Birth is required';
        isValid = false;
    }

    // Qualification validation
    const specialization1 = document.getElementById('specialization1').value;
    const university1 = document.getElementById('university1').value;
    const year1 = document.getElementById('year1').value;
    const college1 = document.getElementById('college1').value;
    const specialization2 = document.getElementById('specialization2').value;
    const university2 = document.getElementById('university2').value;
    const year2= document.getElementById('year2').value;
    const college2 = document.getElementById('college2').value;
    const sgpa1= document.getElementById('sgpa1').value;
    const sgpa2 = document.getElementById('sgpa2').value;
    if (!specialization1 || !university1 || !year1 || !college1 || !specialization2 || !university2 || !year2 || !college2 || !sgpa1 || !sgpa2) {
        document.getElementById('qualificationError').textContent = 'Complete qualification details are required';
        isValid = false;
    }

    // Address validation
    const address = document.getElementById('address').value;
    if (!address) {
        document.getElementById('addressError').textContent = 'Address is required';
        isValid = false;
    }

    // Photo validation
    const photo = document.getElementById('photo').files.length;
    if (photo === 0) {
        document.getElementById('photoError').textContent = 'Photo is required';
        isValid = false;
    }

    // Skills validation
    const skills = document.querySelectorAll('input[name="skills"]:checked');
    if (skills.length === 0) {
        document.getElementById('skillsError').textContent = 'At least one skill is required';
        isValid = false;
    }

    // Department validation
    const department = document.getElementById('department').value;
    if (!department) {
        document.getElementById('departmentError').textContent = 'Department is required';
        isValid = false;
    }

    // Experience validation
    const experience = document.getElementById('experience').value;
    if (experience === "") {
        document.getElementById('experienceError').textContent = 'Experience is required';
        isValid = false;
    }

    if (isValid) {
        displayConfirmation();
    }
}

function alertDepartment() {
    const department = document.getElementById('department').value;
    if (department) {
        alert(department + ' is selected');
    }
}

function displayConfirmation() {
    document.getElementById('confirmation').style.display = 'block';

    document.getElementById('confirmName').textContent = 'Name: ' + document.getElementById('name').value;
    document.getElementById('confirmFatherName').textContent = "Father's Name: " + document.getElementById('fatherName').value;
    document.getElementById('confirmMotherName').textContent = "Mother's Name: " + document.getElementById('motherName').value;
    document.getElementById('confirmPhoneNumber').textContent = 'Phone Number: ' + document.getElementById('phoneNumber').value;
    document.getElementById('confirmEmail').textContent = 'Email: ' + document.getElementById('email').value;
    document.getElementById('confirmDob').textContent = 'Date of Birth: ' + document.getElementById('dobDay').value + '-' + document.getElementById('dobMonth').value + '-' + document.getElementById('dobYear').value;
    document.getElementById('confirmQualification1').textContent = 'Qualification: Specialization - ' + document.getElementById('specialization1').value + ', University - ' + document.getElementById('university1').value + ', Year - ' + document.getElementById('year1').value + ', College - ' + document.getElementById('college1').value +', Marks - ' + document.getElementById('sgpa1').value;
    document.getElementById('confirmQualification2').textContent = 'Qualification: Specialization - ' + document.getElementById('specialization2').value + ', University - ' + document.getElementById('university2').value + ', Year - ' + document.getElementById('year2').value + ', College - ' + document.getElementById('college2').value+', Marks - ' + document.getElementById('sgpa2').value;
    document.getElementById('confirmAddress').textContent = 'Address: ' + document.getElementById('address').value;

    const skills = Array.from(document.querySelectorAll('input[name="skills"]:checked')).map(skill => skill.value).join(', ');
    document.getElementById('confirmSkills').textContent = 'Skills: ' + skills;

    document.getElementById('confirmDepartment').textContent = 'Department: ' + document.getElementById('department').value;
    document.getElementById('confirmExperience').textContent = 'Experience: ' + document.getElementById('experience').value;
}

function confirmDetails() {
    alert('Details confirmed and submitted successfully!');
}
