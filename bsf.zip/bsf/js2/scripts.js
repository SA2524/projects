document.getElementById('quoteForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const travelDates = document.getElementById('travelDates').value;
    const stateResidence = document.getElementById('stateResidence').value;
    const travelerInfo = document.getElementById('travelerInfo').value;
    const initialPayment = document.getElementById('initialPayment').value;

    if (travelDates && stateResidence && travelerInfo && initialPayment) {
        alert('Form submitted successfully!');
    } else {
        alert('Please fill out all fields.');
    }
});
const email = document.getElementById('email').value;
const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email || !emailPattern.test(email)) {
        document.getElementById('emailValidation').textContent = 'Valid email is required';
    } else {
        document.getElementById('emailValidation').textContent = 'Email is valid';
      
    }
